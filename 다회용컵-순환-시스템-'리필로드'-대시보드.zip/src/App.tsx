/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  Recycle, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  RefreshCw, 
  Sparkles
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  Cell
} from "recharts";
import { ApiResponse, PollutionDetail } from "./types";

// Custom polished hover tooltip showing month over month % change
const CustomTrendTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-950 text-white p-3.5 rounded-xl border border-slate-800 shadow-xl text-xs space-y-1">
        <p className="font-bold text-slate-300">{data.name}</p>
        <p className="text-emerald-400 font-bold">
          총 반납량: <span className="font-mono text-sm">{data["총 반납량"].toLocaleString()}개</span>
        </p>
        <p className="text-slate-400 font-medium pt-1.5 border-t border-slate-800 mt-1 flex items-center gap-1">
          <span>전월 대비 증감:</span>
          <span className={`font-semibold ${data.changeRaw >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
            {data["전월 대비 증감"]}
          </span>
        </p>
      </div>
    );
  }
  return null;
};

export default function App() {
  const [data, setData] = useState<ApiResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Selected month state
  const [selectedMonth, setSelectedMonth] = useState<string>("All");

  // Fetch initial dashboard statistics
  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async (forceRefresh = false) => {
    try {
      if (forceRefresh) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }
      setError(null);

      const endpoint = forceRefresh ? "/api/cups-data/refresh" : "/api/cups-data";
      const method = forceRefresh ? "POST" : "GET";
      
      const response = await fetch(endpoint, { method });
      if (!response.ok) {
        throw new Error(`서버 오류가 발생했습니다 (상태 코드: ${response.status})`);
      }
      
      const resData = await response.json();
      const dashboardData: ApiResponse = forceRefresh ? resData.data : resData;
      
      setData(dashboardData);
      
      if (!forceRefresh || selectedMonth === "All") {
        setSelectedMonth(dashboardData.latestMonth);
      }
    } catch (err: any) {
      console.error("데이터 가져오기 실패:", err);
      setError("스프레드시트에서 데이터를 불러오지 못했습니다. 데이터 형식이 올바른지 확인해주세요.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 text-slate-800 font-sans">
        <div className="relative flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-emerald-200 border-t-emerald-600 rounded-full animate-spin"></div>
          <Recycle className="absolute w-6 h-6 text-emerald-600 animate-pulse" />
        </div>
        <h3 className="mt-6 text-lg font-medium tracking-tight">다회용컵 순환 시스템 '리필로드' 대시보드 로딩 중...</h3>
        <p className="mt-2 text-sm text-slate-400">구글 드라이브 스프레드시트에서 최신 데이터를 동기화하고 있습니다.</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 text-slate-800 p-6">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-sm border border-slate-150 p-8 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-red-100 text-red-600 mb-4">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 leading-tight">데이터 연동 실패</h3>
          <p className="mt-3 text-slate-600 text-sm leading-relaxed">{error}</p>
          <button 
            type="button"
            id="retry-btn"
            onClick={() => fetchDashboardData()} 
            className="mt-6 w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold bg-emerald-600 text-white hover:bg-emerald-700 active:scale-[0.98] transition-all"
          >
            <RefreshCw className="w-4 h-4" /> 다시 시도하기
          </button>
        </div>
      </div>
    );
  }

  // --- Calculations for dashboard KPIs & trends ---
  const currentMonthReturns: Record<string, number> = (data.monthlyBinReturns[selectedMonth] || {}) as Record<string, number>;
  
  const totalReturnsOverall = data.monthlyTrends.reduce((sum, item) => sum + Number(item.totalReturns), 0);
  const totalReturnsSelectedMonth = (Object.values(currentMonthReturns) as number[]).reduce((sum, val) => sum + Number(val), 0);

  // Live Carbon reduction: 33 gCO2-eq per cup overall
  const overallCarbonReductionG = totalReturnsOverall * 33;
  const overallCarbonReductionKg = overallCarbonReductionG / 1000;

  // Selected Month Trend compared to previous month
  const selectedMonthIdx = data.months.indexOf(selectedMonth);
  let previousMonthStr = "";
  let percentDiff = 0;
  let hasDiff = false;
  let isTrendUp = true;

  if (selectedMonthIdx > 0) {
    previousMonthStr = data.months[selectedMonthIdx - 1];
    const prevReturnsRecord: Record<string, number> = (data.monthlyBinReturns[previousMonthStr] || {}) as Record<string, number>;
    const prevMonthTotal = (Object.values(prevReturnsRecord) as number[]).reduce((sum, val) => sum + Number(val), 0);
    
    if (prevMonthTotal > 0) {
      hasDiff = true;
      const diffVal = totalReturnsSelectedMonth - prevMonthTotal;
      percentDiff = parseFloat(((Math.abs(diffVal) / prevMonthTotal) * 100).toFixed(1));
      isTrendUp = diffVal >= 0;
    }
  }

  const pollutionDetailList: PollutionDetail[] = data.monthlyPollution[selectedMonth] || [];

  const latestMonthBinReturnsList = Object.entries(currentMonthReturns).map(([binName, count]) => ({
    binName,
    count: Number(count)
  }));

  const sortedReturns = [...latestMonthBinReturnsList].sort((a,b) => b.count - a.count);
  const topReturns = sortedReturns.slice(0, 3);
  const bottomReturns = [...sortedReturns].reverse().slice(0, 3);

  const trackedPollutionList = pollutionDetailList.filter(p => Number(p.totalTrash) > 0);

  const topContaminated = [...trackedPollutionList]
    .sort((a,b) => Number(b.contaminationRate) - Number(a.contaminationRate))
    .slice(0, 3);

  const topWcRatio = [...trackedPollutionList]
    .sort((a,b) => Number(b.wcRatio) - Number(a.wcRatio))
    .slice(0, 3);

  const bottomContaminated = [...trackedPollutionList]
    .sort((a,b) => Number(a.contaminationRate) - Number(b.contaminationRate))
    .slice(0, 3);

  const averageContamination = trackedPollutionList.length > 0
    ? parseFloat((trackedPollutionList.reduce((sum, item) => sum + Number(item.contaminationRate), 0) / trackedPollutionList.length).toFixed(1))
    : 0;

  // Formatting for Recharts trend rendering with embedded pre-processed diff for tooltip hover
  const trendChartData = data.monthlyTrends.map((item, index) => {
    const yr = item.date.split('.')[0].substring(2);
    const mo = parseInt(item.date.split('.')[1]);
    
    let pctChangeStr = "";
    let changeRaw = 0;
    if (index > 0) {
      const prevTotal = Number(data.monthlyTrends[index - 1].totalReturns);
      const currTotal = Number(item.totalReturns);
      if (prevTotal > 0) {
        changeRaw = currTotal - prevTotal;
        const pctAbs = Math.abs((changeRaw / prevTotal) * 100).toFixed(1);
        pctChangeStr = changeRaw >= 0 ? `+${pctAbs}% 증가` : `-${pctAbs}% 감소`;
      }
    } else {
      pctChangeStr = "첫 기록 월";
    }

    return {
      name: `${yr}년 ${mo}월`,
      rawValue: item.date,
      "총 반납량": Number(item.totalReturns),
      "전월 대비 증감": pctChangeStr,
      changeRaw: changeRaw
    };
  });

  const binChartData = latestMonthBinReturnsList.map(item => ({
    name: item.binName,
    "반납 수거량": Number(item.count)
  })).sort((a,b) => b["반납 수거량"] - a["반납 수거량"]);

  const formattedMonthLabel = (monthStr: string) => {
    if (monthStr === "All") return "전체 기간";
    const parts = monthStr.split(".");
    return `${parts[0]}년 ${parseInt(parts[1])}월`;
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans antialiased flex flex-col justify-between">
      
      {/* Header Block */}
      <header className="flex flex-col sm:flex-row items-center justify-between px-8 py-4 bg-white border-b border-slate-200 shadow-sm gap-4 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center text-white shadow-md">
            <Recycle className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-800 flex items-center gap-2">
              다회용컵 순환 시스템 '리필로드' 대시보드
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100">
                실시간 데이터
              </span>
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              데이터 기준: {formattedMonthLabel(selectedMonth)} 리얼타임 분석
            </p>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          <button
            id="refresh-data-btn"
            type="button"
            onClick={() => fetchDashboardData(true)}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-400 text-white rounded-md text-sm font-semibold transition-all cursor-pointer shadow-sm"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? '동기화 중...' : '스프레드시트 동기화'}</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto w-full p-6 space-y-8">

        {/* ==================== [BOX 1]전체 누적 관련 및 트렌드 분석 ==================== */}
        <section className="bg-emerald-50/15 p-6 rounded-2xl border-2 border-emerald-500/20 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-emerald-500/10 pb-3">
            <h2 className="text-base font-extrabold text-emerald-800 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              누적 / 월 별 사용량 추이
            </h2>
            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 border border-emerald-100 rounded-full tracking-wider uppercase font-mono">
              Cumulative & monthly trend
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* 전체 누적 반납 수거량 */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50/50 rounded-full translate-x-12 -translate-y-12 transition-transform duration-500 group-hover:scale-110" />
              <div className="relative z-10">
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 border border-emerald-100 rounded-full uppercase tracking-wider">
                  Cumulative Vol
                </span>
                <p className="text-xs font-semibold text-slate-500 mt-4 uppercase tracking-wider">전체 누적 반납 수거량</p>
                <h3 className="text-4xl font-extrabold text-slate-800 tracking-tight mt-2.5">
                  {totalReturnsOverall.toLocaleString()}<span className="text-sm font-medium text-slate-400 ml-1.5">개</span>
                </h3>
              </div>
              <p className="text-[11px] text-slate-400 relative z-10 pt-4 border-t border-slate-100 mt-4">
                25년 9월부터 현재까지 다회용컵 사용량
              </p>
            </div>

            {/* 탄소 감축량 */}
            <div className="bg-emerald-950 p-6 rounded-xl border border-emerald-900 shadow-md flex flex-col justify-between text-white relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-900/40 rounded-full translate-x-12 -translate-y-12 transition-transform duration-500 group-hover:scale-110" />
              <div className="relative z-10">
                <span className="text-[10px] font-bold text-emerald-200 bg-emerald-900 px-2.5 py-1 border border-emerald-800 rounded-full uppercase tracking-wider">
                  Carbon Save
                </span>
                <p className="text-xs font-semibold text-emerald-200 mt-4 uppercase tracking-wider">누적 탄소 감축량 (CO₂-eq)</p>
                <h3 className="text-3xl font-extrabold text-[#34d399] tracking-tight mt-2.5">
                  {overallCarbonReductionKg.toLocaleString(undefined, { maximumFractionDigits: 1 })}<span className="text-sm font-medium text-emerald-200 ml-1.5">kg CO₂-eq</span>
                </h3>
              </div>
              <p className="text-[11px] text-emerald-100/80 relative z-10 pt-4 border-t border-emerald-850 mt-4 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
                <span>컵 1개당 <strong>33 gCO₂-eq</strong> 탄소 저감 효과 가산</span>
              </p>
            </div>
          </div>

          {/* 월 별 다회용컵 총 반납 수거량 추이 */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col min-h-[385px]">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                  <div className="w-1.5 h-4 bg-emerald-500 rounded-full"></div>
                  월 별 다회용컵 총 사용량 추이
                </h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  * 막대에 마우스 오버 시 전월 대비 증감(%) 정보를 제공합니다.
                </p>
              </div>
              <span className="p-1 px-2.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 rounded border border-emerald-100 uppercase font-mono">
                Overall Trend Chart
              </span>
            </div>
            
            <div className="flex-1 w-full h-[260px] mt-4">
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={trendChartData} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                  <defs>
                    <linearGradient id="polishedGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#059669" stopOpacity={0.88} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.3} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fill: '#64748b', fontSize: 11 }} 
                    axisLine={{ stroke: '#e2e8f0' }} 
                    tickLine={false}
                  />
                  <YAxis 
                    tick={{ fill: '#64748b', fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip content={<CustomTrendTooltip />} cursor={{ fill: 'rgba(16, 185, 129, 0.05)' }} />
                  <Bar 
                    dataKey="총 반납량" 
                    fill="url(#polishedGradient)" 
                    radius={[4, 4, 0, 0]}
                  >
                    {trendChartData.map((entry) => (
                      <Cell 
                        key={`cell-${entry.rawValue}`}
                        stroke={entry.rawValue === selectedMonth ? '#047857' : 'transparent'}
                        strokeWidth={2}
                        cursor="pointer"
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        {/* ==================== [BOX 2]월간 세부 조회 및 오염률 모니터링 ==================== */}
        <section className="bg-slate-50/30 p-6 rounded-2xl border-2 border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h2 className="text-base font-extrabold text-slate-800 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
              월간 상세 검색 및 실태 조회 모니터링
            </h2>
            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2.5 py-1 border border-slate-200 rounded-full tracking-wider uppercase font-mono">
              Monthly search & query
            </span>
          </div>

          {/* 조회 기간 선택 (Q) */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-2">
                <Calendar className="w-4 h-4 text-slate-500" /> 조회 기간 선택
              </span>
              <div className="bg-slate-100 p-1 rounded-lg flex flex-wrap gap-1">
                {data.months.map((month) => (
                  <button
                    key={month}
                    id={`filter-month-${month.replace('.', '-')}`}
                    type="button"
                    onClick={() => setSelectedMonth(month)}
                    className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                      selectedMonth === month
                        ? "bg-white text-emerald-700 shadow-xs font-bold"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {formattedMonthLabel(month)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Frame: 수거장소별 반납분포 & 월간 총합 (8/12) */}
            <div className="lg:col-span-8 flex flex-col gap-6">
              
              {/* 월간 총 반납 수거량 카드 */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded">Monthly Total</span>
                  <p className="text-xs font-semibold text-slate-500 mt-2.5 uppercase tracking-wider">월간 총 반납 수거량 ({formattedMonthLabel(selectedMonth)})</p>
                  <p className="text-3xl font-extrabold text-slate-850 mt-1">
                    {totalReturnsSelectedMonth.toLocaleString()}<span className="text-sm font-normal text-slate-400 ml-1">개</span>
                  </p>
                </div>
                <div className="text-right">
                  {hasDiff ? (
                    <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold ${
                      isTrendUp ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-rose-50 text-rose-700 border border-rose-100'
                    }`}>
                      {isTrendUp ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                      <span>전월 대비 {isTrendUp ? `+${percentDiff}%` : `-${percentDiff}%`} {isTrendUp ? "증가" : "감소"}</span>
                    </div>
                  ) : (
                    <span className="text-xs font-semibold text-slate-400 italic bg-slate-100 px-2.5 py-1.5 rounded-lg border border-slate-200/50">
                      전월 데이터 없음
                    </span>
                  )}
                  <p className="text-[10px] text-slate-400 mt-2">
                    최다 반납지역: <strong className="text-slate-600 font-bold">{topReturns[0] ? topReturns[0].binName : "기록 없음"}</strong>
                  </p>
                </div>
              </div>

              {/* 수거장소별 반납분포 그래프 차트 */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between min-h-[360px]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                  <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <div className="w-1.5 h-4 bg-emerald-500 rounded-full"></div>
                    수거장소별 반납분포 ({formattedMonthLabel(selectedMonth)})
                  </h3>
                  <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2.5 py-0.5 border border-slate-200 rounded font-mono">
                    14 Bins Active
                  </span>
                </div>
                
                <div className="w-full h-[230px]">
                  <ResponsiveContainer width="100%" height={230}>
                    <BarChart data={binChartData} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                      <XAxis 
                        dataKey="name" 
                        tick={{ fill: '#475569', fontSize: 9 }}
                        axisLine={{ stroke: '#e2e8f0' }}
                        tickLine={false}
                      />
                      <YAxis tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} />
                      <Tooltip />
                      <Bar dataKey="반납 수거량" fill="#10b981" radius={[3, 3, 0, 0]}>
                        {binChartData.map((entry, index) => {
                          const isTop = index < 3;
                          return <Cell key={`cell-bin-${entry.name}`} fill={isTop ? "#059669" : "#94a3b8"} />;
                        })}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-[10px] text-slate-400 mt-3 pt-3 border-t border-slate-150 font-medium">
                  <div>* 짙은 에메랄드색 막대는 당월 수거량 랭킹 TOP 3 거점입니다.</div>
                  <div className="flex gap-4">
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#059669] rounded-sm" /> 상위 3개 지역</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#94a3b8] rounded-sm" /> 일반 구역</span>
                  </div>
                </div>
              </div>

              {/* 반납처별 격차 리스트 (TOP 3 vs BOTTOM 3) */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <h4 className="text-xs font-bold text-slate-600 mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-500" />
                  반납처별 격차 리스트
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2 bg-emerald-50/20 border border-emerald-150 rounded-lg p-3">
                    <p className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider flex items-center gap-1">🥇 최다 반납처 (TOP 3)</p>
                    {topReturns.map((item, idx) => (
                      <div key={item.binName} className="flex items-center justify-between text-xs bg-white p-2.5 rounded border border-emerald-100">
                        <span className="text-slate-700 font-medium">{idx + 1}. {item.binName}</span>
                        <span className="font-mono font-bold text-emerald-700">{item.count.toLocaleString()}개</span>
                      </div>
                    ))}
                  </div>
                  <div className="space-y-2 bg-slate-50 border border-slate-200 rounded-lg p-3">
                    <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1">💤 최소 반납처 (BOTTOM 3)</p>
                    {bottomReturns.map((item, idx) => (
                      <div key={item.binName} className="flex items-center justify-between text-xs bg-white p-2.5 rounded border border-slate-150">
                        <span className="text-slate-600 font-medium">{item.binName}</span>
                        <span className="font-mono text-slate-500">{item.count}개</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>

            {/* Right Frame: 오염률 및 컵 1개당 쓰레기량 분석 (4/12) */}
            <div className="lg:col-span-4 flex flex-col gap-6">
              
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex-1 flex flex-col justify-between min-h-[380px]">
                <div>
                  <h3 className="text-sm font-bold text-slate-700 mb-2 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-500" />
                      월간 반납함 오염 관리
                    </span>
                    <span className="text-[10px] text-slate-500 bg-slate-100 border border-slate-200 px-2.5 py-0.5 rounded font-bold font-mono">
                      G & H Analysis
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mb-4 leading-normal">
                    수거처의 오염률과 컵 1개당 혼입된 쓰레기량을 추적하여 실시간 위생 대상지를 분석합니다.
                  </p>
                </div>

                {/* Left & Right columns inside the card */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-5 flex-1">
                  
                  {/* Left sub-column: 오염률 TOP 3 */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between border-b border-rose-100 pb-1.5">
                      <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 border border-rose-100 rounded">
                        오염률 TOP 3
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      {topContaminated.length > 0 ? (
                        topContaminated.map((item, idx) => (
                          <div key={`g-top-${item.binName}`} className="flex items-center gap-2.5 p-2 rounded-lg bg-rose-50/30 border border-rose-100/50 text-xs">
                            <div className="w-5 h-5 rounded bg-rose-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0">
                              {idx + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-slate-800 text-[11px] truncate">{item.binName}</p>
                            </div>
                            <span className="text-rose-600 font-extrabold font-mono text-[11px] shrink-0">{item.contaminationRate}%</span>
                          </div>
                        ))
                      ) : (
                        <p className="text-[11px] text-slate-400 italic py-2 text-center">측정 데이터 없음</p>
                      )}
                    </div>
                  </div>

                  {/* Right sub-column: 컵 1개당 쓰레기량 TOP 3 */}
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between border-b border-amber-100 pb-1.5">
                      <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 border border-amber-100 rounded">
                        컵 1개당 쓰레기량 TOP 3
                      </span>
                    </div>
                    
                    <div className="space-y-2">
                      {topWcRatio.length > 0 ? (
                        topWcRatio.map((item, idx) => (
                          <div key={`h-top-${item.binName}`} className="flex items-center gap-2.5 p-2 rounded-lg bg-amber-50/30 border border-amber-100/50 text-xs">
                            <div className="w-5 h-5 rounded bg-amber-500 text-white font-bold flex items-center justify-center text-[10px] shrink-0">
                              {idx + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-slate-800 text-[11px] truncate">{item.binName}</p>
                            </div>
                            <span className="text-amber-600 font-extrabold font-mono text-[11px] shrink-0">{item.wcRatio}개</span>
                          </div>
                        ))
                      ) : (
                        <p className="text-[11px] text-slate-400 italic py-2 text-center">측정 데이터 없음</p>
                      )}
                    </div>
                  </div>

                </div>

                <div className="mt-4 pt-3 border-t border-slate-150 text-[10px] text-slate-400 space-y-1.5 leading-normal">
                  <div>
                    <span className="font-bold text-slate-500">· 오염률:</span> 쓰레기 수 ÷ (컵 수 + 쓰레기 수)
                    <span className="text-rose-600 block pl-2 font-medium">* 컵 개수가 적은 반납함도 오염률이 높게 나올 수 있음</span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-500">· 컵 1개당 쓰레기량:</span> 쓰레기 수 ÷ 컵 수
                    <span className="text-amber-600 block pl-2 font-medium">* 반납된 컵 한 개당 평균적으로 얼마나 많은 쓰레기가 버려졌는지</span>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </section>

      </main>
      
      {/* Footer Block */}
      <footer className="h-14 bg-white border-t border-slate-200 px-8 flex items-center justify-between text-xs text-slate-500">
        <div>
          © 2026 Eco-Cycle Analytics System | 동기화: 원격 구글 스프레드시트 연동 완료
        </div>
        <div className="flex items-center gap-4">
          <span>System Status: <span className="text-emerald-600 font-bold">Optimal</span></span>
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
        </div>
      </footer>

    </div>
  );
}
