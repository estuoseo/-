/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BinReturnVolume {
  binName: string;
  count: number;
}

export interface MonthlyReturnTrend {
  date: string; // YYYY.MM
  totalReturns: number;
}

export interface PollutionDetail {
  binName: string;
  generalTrash: number;
  disposableCups: number;
  reusableCups: number;
  totalTrash: number;
  contaminationRate: number; // Percentage: (general + disposable) / total * 100
  wcRatio: number; // Waste per single reusable cup ratio (H-column W/C)
}

export interface MonthlyBinData {
  [binName: string]: number;
}

export interface ApiResponse {
  months: string[];
  latestMonth: string;
  monthlyTrends: MonthlyReturnTrend[];
  // Month string -> Bin returns record
  monthlyBinReturns: { [month: string]: MonthlyBinData };
  // Accumulated or month-specific pollution details
  monthlyPollution: { [month: string]: PollutionDetail[] };
  overallPollution: PollutionDetail[];
  lastUpdated: string;
}
